# bower-angular-input-masks
Distribution repo for [angular-input-masks](https://github.com/assisrafael/angular-input-masks). Please file issues and pull requests against that repo.
